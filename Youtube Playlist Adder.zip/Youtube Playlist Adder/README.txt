--Youtube Playlist Adder--
How to Setup:
	1. Have at least java 8 downloaded (jre8/1.8)
	2. Unzip the contents of the file
	3. The client_secrets must be in the same directory as jar file to work
	4. Go to Google Developer Console @ https://console.cloud.google.com/apis/dashboard
	5. Select create new project
	6. Complete the prompts
	7. Then select the project from the dashboard
	8. Select enable APIS and Services
	9. Search for Youtube Data API v3 and enable
	10. Go back to dashboard and select oauth consent screen
	11. Complete prompts
	12. Select Credentials
	13. Create Oauth2.0 Credentials
	14. Select edit and click download client secrets json file
	15. Copy what is in json file and paste into client_secret in jar directory

How to Use:
	1. If client secrets file contents are correctly added and is in same directory as jar file
	   it is ready for use.
	2. Double click the jar (open with java/jre1.8/bin/javaw.exe)
	3. Paste the URL of the playlist you would like to get videos from
	4. Next paste the URL of the playlist you want the videos added to
	5. Click Run and wait for videos to get added
	6. You can check you quota left per day @ https://console.cloud.google.com/iam-admin/quotas/details
	   You only get 10,000 quota per day for free and 1 video read request cost 1 quota while 1 video add 
	   request costs 50 quota. You to add about 200 videos before your quota maxes out. You can also create a 
	   new project with credentials and replace client_secret.json with different oauth2.0 credentials.